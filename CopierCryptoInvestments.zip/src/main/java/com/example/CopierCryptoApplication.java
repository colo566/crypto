package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import jakarta.persistence.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;
import java.util.Random;

@SpringBootApplication
@Controller
public class CopierCryptoApplication {

    public static void main(String[] args) {
        SpringApplication.run(CopierCryptoApplication.class, args);
    }

    @Autowired private UserRepository userRepository;
    @Autowired private WalletRepository walletRepository;
    
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    private final Random random = new Random();

    @GetMapping("/")
    public String home() { return "login"; }

    @GetMapping("/register")
    public String showRegisterPage() { return "register"; }

    @PostMapping("/register")
    public String register(@RequestParam String username, @RequestParam String password) {
        if (userRepository.findByUsername(username).isPresent()) return "error";
        
        User user = new User(username, passwordEncoder.encode(password));
        Wallet wallet = new Wallet(user);
        user.setWallet(wallet);
        userRepository.save(user);
        walletRepository.save(wallet);
        return "redirect:/";
    }

    @PostMapping("/login")
    public ModelAndView login(@RequestParam String username, @RequestParam String password) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent() && passwordEncoder.matches(password, userOpt.get().getPassword())) {
            return new ModelAndView("dashboard").addObject("user", userOpt.get());
        }
        return new ModelAndView("error");
    }

    @GetMapping("/dashboard")
    public String dashboard(@RequestParam Long userId, Model model) {
        User user = userRepository.findById(userId).orElseThrow();
        model.addAttribute("balance", user.getWallet().getBalance());
        model.addAttribute("username", user.getUsername());
        return "dashboard";
    }

    @GetMapping("/updateBalance")
    @ResponseBody
    public double updateBalance(@RequestParam Long userId) {
        Wallet wallet = walletRepository.findByUserId(userId);
        wallet.setBalance(wallet.getBalance() + random.nextDouble() * 0.01);
        walletRepository.save(wallet);
        return wallet.getBalance();
    }

    @GetMapping("/withdraw")
    @ResponseBody
    public String withdraw(@RequestParam Long userId) {
        return "Error: Transaction failed. Contact support.";
    }
}

@Entity
class User {
    @Id @GeneratedValue private Long id;
    private String username;
    private String password;
    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL) private Wallet wallet;
    public User() {} public User(String username, String password) { this.username = username; this.password = password; }
    public String getUsername() { return username; } public String getPassword() { return password; }
    public Wallet getWallet() { return wallet; } public void setWallet(Wallet wallet) { this.wallet = wallet; }
}

@Entity
class Wallet {
    @Id @GeneratedValue private Long id;
    private double balance = 0.5;
    @OneToOne @JoinColumn(name = "user_id") private User user;
    public Wallet() {} public Wallet(User user) { this.user = user; }
    public double getBalance() { return balance; } public void setBalance(double balance) { this.balance = balance; }
}

interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
}

interface WalletRepository extends JpaRepository<Wallet, Long> {
    Wallet findByUserId(Long userId);
}
